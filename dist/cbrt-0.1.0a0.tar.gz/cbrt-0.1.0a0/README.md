# "cbrt" package

**Note:** This is an early version of the `cbrt` package. There is no functionality at the moment, but features will be added in future releases.

```shell
cbrt/
├── cbrt/
│   ├── __init__.py
│   └── api.py
│   └── config.py
├── setup.py
└── README.md

```