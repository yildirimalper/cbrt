```shell
cbrt/
├── cbrt/
│   ├── __init__.py
│   └── api.py
│   └── config.py
├── setup.py
└── README.md

```